<?php require('global/header.php')?>
    <?php require('pages/'.$url.'/index.php')?>
<?php require('global/footer.php')?>