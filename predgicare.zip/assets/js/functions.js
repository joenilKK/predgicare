$(document).ready(function(){
    //login
    // $('.btn-submit').click(function(){
    //     var formName = $(this).attr('data-form')

    //     $('form[form-name='+formName+']').submit(function(e){
    //         e.preventDefault()
    //         alert($('.'+formName+' #exampleInputPassword1').val())
    //         $('.'+formName+' input').each(function(){
    //             alert($(this).val())
    //         })
    //     })
    // })
})