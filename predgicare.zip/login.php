<?php require('global/header.php')?>
      <?php require('pages/login/index.php')?>
<?php require('global/footer.php')?>