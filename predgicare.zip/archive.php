<?php require('global/header.php')?>
  <?php require('pages/home/index.php')?>
<?php require('global/footer.php')?>