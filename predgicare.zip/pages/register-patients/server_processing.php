<?php
    require('../../classes/serverProcessing.php');

    $args = array("uid", "uFirstName", "uMname", "uLstName");
    $key = 'uid';
    $tb = 'user';
    DataTableSSR($args,$key,$tb);