<?php

?>
<div class="row g-0">
    <div class="col col-8">
        <img src="../../images/loginPromotion.png" class="img-fluid img-thumbnail" alt="...">
    </div>
    <div class="col col-4 col-8-md login-form-wrapper">
        <div class="login-image">
            <img src="../../images/loginLogo.svg" class="rounded mx-auto d-block" alt="...">
            <img src="../../images/PredgiCare.svg" class="rounded mx-auto d-block" alt="...">
        </div>
        <div class="login-form">
            <h3 class="text-center">Log in to continue</h3>
            <form method="POST">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Username</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1">
                </div>
                <div class="d-grid gap-2">
                    <button 
                        type="submit" 
                        class="btn btn-primary btn-submit"
                    >
                        Login
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>