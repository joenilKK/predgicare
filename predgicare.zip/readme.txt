Name Pages structure

Form submit params
- button should have a form name it is attached
- button should have 'btn-sbmit' class

GLOBAL PHP FUNCTION
- DataTableSSR()
  * $args = an array the represent the column in the table 
  * $key = a ordering key you wanted
  * $tb = table name you wanted to query